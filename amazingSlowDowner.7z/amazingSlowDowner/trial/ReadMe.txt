Welcome to Amazing Slow Downer for Windows!


If you're a musician who likes to learn new songs and techniques by
listening to the same piece of music over and over but wish that the
music could be played a little slower, then you'll enjoy Amazing Slow 
Downer. You can repeat any section of the music at full speed, slow it
down or even speed it up by stretching the music by -50% to 400%
without changing the pitch!
 
You can also change the pitch up or down in semi-tones or fine-tune in cents (100ths of a semi-tone) to 
suit your instrument.

This 32-bit program works with your CD-ROM drive or any MP3//Wave file on 
your harddisk and does all processing in real-time - no time wasted on recording or processing!

Just press the play button and - GO!


------------------------------------------------------------------------

Installing.

In order to run Amazing Slow Downer for Windows you first have to
install it onto your harddisk using the installation program.


Installing procedure:

Run the Setup.exe program.

The Setup program creates a program group called "Amazing Slow Downer"
in the Start Menu.


For more info or questions of any kinds, please contact Roni Music
https://www.ronimusic.com

� Copyright 2001-2021Roni Music - All Rights Reserved.
